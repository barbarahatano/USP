#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "exercicio1.h"


int encontrar_expressao(int lista[], char expressoes[][100], int tamanho, int valor_alvo, int *chamadas_recursivas) {
    
    (*chamadas_recursivas)++;

    //condicao de parada
    if (tamanho == 1) {
        if (lista[0] == valor_alvo) {
            printf("Expressao encontrada: %s = %d\n", expressoes[0], valor_alvo);

            return 1;
        }

        return 0;
    }

    // itera sobre todos os pares (i, j) da lista
    int i = 0;
    while (i < tamanho) {
        int j = i + 1;
        while (j < tamanho) {
            // vetores para a proxima chamada recursiva (com tamanho - 1)
            int nova_lista[6];
            char novas_expressoes[6][100];
            int k_escrita = 0;
            int k_leitura = 0;

            // copia os elementos nao utilizados para os novos vetores
            while (k_leitura < tamanho) {
                if (k_leitura != i && k_leitura != j) {
                    nova_lista[k_escrita] = lista[k_leitura];
                    strcpy(novas_expressoes[k_escrita], expressoes[k_leitura]);
                    k_escrita++;
                }
                k_leitura++;
            }

            // testes (se qualquer chamada retornar 1, propaga o sucesso)

            // testa soma
            nova_lista[k_escrita] = lista[i] + lista[j];
            sprintf(novas_expressoes[k_escrita], "(%s + %s)", expressoes[i], expressoes[j]);
            if (encontrar_expressao(nova_lista, novas_expressoes, tamanho - 1, valor_alvo, chamadas_recursivas)) return 1;

            //testa subtracao
            nova_lista[k_escrita] = lista[i] - lista[j];
            sprintf(novas_expressoes[k_escrita], "(%s - %s)", expressoes[i], expressoes[j]);
            if (encontrar_expressao(nova_lista, novas_expressoes, tamanho - 1, valor_alvo, chamadas_recursivas)) return 1;

            //testa multiplicacao
            nova_lista[k_escrita] = lista[i] * lista[j];
            sprintf(novas_expressoes[k_escrita], "(%s * %s)", expressoes[i], expressoes[j]);
            if (encontrar_expressao(nova_lista, novas_expressoes, tamanho - 1, valor_alvo, chamadas_recursivas)) return 1;

            //testa divisao
            //so se for exata e nao divide por 0
            if (lista[j] != 0 && lista[i] % lista[j] == 0) {
                nova_lista[k_escrita] = lista[i] / lista[j];
                sprintf(novas_expressoes[k_escrita], "(%s / %s)", expressoes[i], expressoes[j]);
                if (encontrar_expressao(nova_lista, novas_expressoes, tamanho - 1, valor_alvo, chamadas_recursivas)) return 1;
            }

            j++;
        }
        i++;
    }

    return 0;
}
