#ifndef EXERCICIO1_H
#define EXERCICIO1_H

// buscar a expressao
int encontrar_expressao(int lista[], char expressoes[][100], int tamanho, int valor_alvo, int *chamadas_recursivas);

#endif
