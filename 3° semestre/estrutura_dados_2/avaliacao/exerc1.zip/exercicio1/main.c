#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "exercicio1.h"

void rodar(int lista[], int tamanho, int alvo) {

    //define as expressoes
    char expressoes[6][100];
    for (int i = 0; i < tamanho; i++) {
        sprintf(expressoes[i], "%d", lista[i]);
    }

    //inicializa chamadas
    int chamadas = 0;

    printf("\n");

    int deu_certo = encontrar_expressao(lista, expressoes, tamanho, alvo, &chamadas);

    if (!deu_certo) {
        printf("Nao foi possivel formar o valor alvo.\n");
    }


    printf("Chamadas recursivas: %d\n", chamadas);
}

int main(int argc, char *argv[]) {


    if (argc == 3) { //passou parametros

        int lista_numeros[6];
        int tamanho = 0;

        //define lista e tamanho
        char *token = strtok(argv[1], ",");
        while (token != NULL && tamanho < 6) {
            lista_numeros[tamanho++] = atoi(token);
            token = strtok(NULL, ",");
        }

        //define alvo
        int alvo = atoi(argv[2]);

        //roda codigo
        rodar(lista_numeros, tamanho, alvo);
    } else { //nao passou parametros
        int lista1[] = {3, 4, 2};
        rodar(lista1, 3, 14);

        int lista2[] = {5, 2, 1, 8};
        rodar(lista2, 4, 16);
    }

    printf("\n");
    
    return 0;
}
