#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pesquisa.h"

// Define constantes para o tamanho máximo dos vetores
#define TAMANHO_MAX_VETOR 50
#define TAMANHO_MAX_VALORES 20

// Protótipo da função que executa os testes
void executarTesteDeBusca(int vetor[], int tamanhoVetor, int valoresParaBuscar[], int numValores, int ordemCrescente);

/**
 * @brief Função principal que gerencia a execução do programa.
 * * @param argc Número de argumentos da linha de comando.
 * @param argv Vetor de strings com os argumentos.
 * @return 0 em caso de sucesso, 1 em caso de erro.
 */
int main(int argc, char *argv[]) {
    // Caso 1: Nenhum parâmetro informado, executa os testes padrão definidos no exercício.
    if (argc == 1) {
        printf("--- Teste Padrão 1 (ascendente) ---\n");
        int vetor1[] = {1, 2, 3, 3, 3, 4, 5, 6};
        int valores1[] = {3, 7};
        executarTesteDeBusca(vetor1, 8, valores1, 2, 1); // 1 significa ordem crescente

        printf("\n--- Teste Padrão 2 (descrescente) ---\n");
        int vetor2[] = {8, 8, 6, 5, 5, 5, 3, 2, 1};
        int valores2[] = {5, 8, 7};
        executarTesteDeBusca(vetor2, 9, valores2, 3, 0); // 0 significa ordem decrescente
    } 
    // Caso 2: Parâmetros informados via linha de comando.
    else if (argc == 4) {
        printf("--- Teste via Parâmetros ---\n");
        
        // Vetores para armazenar os dados extraídos dos parâmetros
        int vetorParametros[TAMANHO_MAX_VETOR];
        int tamanhoVetorParametros = 0;
        
        int valoresParametros[TAMANHO_MAX_VALORES];
        int tamanhoValoresParametros = 0;

        // Analisa o primeiro argumento (argv[1]): o vetor de números.
        // strtok divide a string com base no delimitador ",".
        // nas especificações disse que a função deve ser estritamente recursiva, entao acredito que para ler os elementos esteja liberado usar laços de repetição.
        char *token = strtok(argv[1], ",");
        while (token != NULL && tamanhoVetorParametros < TAMANHO_MAX_VETOR) {
            vetorParametros[tamanhoVetorParametros++] = atoi(token); // atoi converte string para inteiro
            token = strtok(NULL, ",");
        }

        // Analisa o segundo argumento (argv[2]): a ordem de classificação.
        // strcmp compara duas strings. Retorna 0 se forem iguais.
        int ordemCrescente = (strcmp(argv[2], "asc") == 0);

        // Analisa o terceiro argumento (argv[3]): os valores a serem buscados.
        token = strtok(argv[3], ",");
        while (token != NULL && tamanhoValoresParametros < TAMANHO_MAX_VALORES) {
            valoresParametros[tamanhoValoresParametros++] = atoi(token);
            token = strtok(NULL, ",");
        }
        
        // Executa o teste com os dados extraídos dos parâmetros
        executarTesteDeBusca(vetorParametros, tamanhoVetorParametros, valoresParametros, tamanhoValoresParametros, ordemCrescente);

    } else {
        // Caso de uso incorreto, exibe uma mensagem de ajuda.
        printf("Uso incorreto!\n");
        printf("Para testes padrão: ./exerc2_main\n");
        printf("Para teste com parâmetros: ./exerc2_main <vetor> <ordem> <valores>\n");
        printf("Exemplo: ./exerc2_main 1,2,5,5,8 asc 5,9\n");
    }

    return 0;
}

/**
 * @brief Função auxiliar que executa um teste de busca e imprime os resultados.
 */
void executarTesteDeBusca(int vetor[], int tamanhoVetor, int valoresParaBuscar[], int numValores, int ordemCrescente) {
    // Itera sobre todos os valores que precisam ser buscados
    for (int i = 0; i < numValores; i++) {
        int valorAlvo = valoresParaBuscar[i];
        
        // Chama as funções de busca para encontrar o primeiro e o último índice
        int primeiraOcorrencia = encontrarPrimeiraOcorrencia(vetor, 0, tamanhoVetor - 1, valorAlvo, ordemCrescente);
        int ultimaOcorrencia = encontrarUltimaOcorrencia(vetor, 0, tamanhoVetor - 1, valorAlvo, ordemCrescente, tamanhoVetor);
        
        // Imprime o resultado formatado
        printf("Valor: %d -> Resultado: (%d, %d)\n", valorAlvo, primeiraOcorrencia, ultimaOcorrencia);
    }
}