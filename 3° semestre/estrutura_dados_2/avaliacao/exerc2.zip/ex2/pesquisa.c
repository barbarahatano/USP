#include "pesquisa.h"
#include <stdio.h>

// Implementação da função recursiva para encontrar o primeiro índice
int encontrarPrimeiraOcorrencia(int vetor[], int inicio, int fim, int valorBuscado, int ordemCrescente) {
    // Caso base da recursão: se o início ultrapassa o fim, o valor não está no vetor.
    if (fim >= inicio) {
        // Calcula o índice do meio para evitar overflow
        int meio = inicio + (fim - inicio) / 2;

        // Verifica se o elemento do meio é uma ocorrência do valor E se é a PRIMEIRA.
        // A segunda parte da condição verifica se o elemento anterior é menor (ou se é o primeiro elemento do vetor).
        if ((vetor[meio] == valorBuscado) && (meio == 0 || (ordemCrescente ? vetor[meio - 1] < valorBuscado : vetor[meio - 1] > valorBuscado))) {
            return meio; // Encontrou a primeira ocorrência
        }
        
        // Se o valor buscado for maior que o do meio (em ordem crescente), busca na metade direita.
        // Se o valor buscado for menor que o do meio (em ordem decrescente), busca na metade direita.
        if (ordemCrescente ? valorBuscado > vetor[meio] : valorBuscado < vetor[meio]) {
            return encontrarPrimeiraOcorrencia(vetor, (meio + 1), fim, valorBuscado, ordemCrescente);
        }
        
        // Caso contrário, continua buscando na metade esquerda (incluindo o caso onde encontramos o valor, mas não é a primeira ocorrência).
        return encontrarPrimeiraOcorrencia(vetor, inicio, (meio - 1), valorBuscado, ordemCrescente);
    }
    
    // Retorna -1 se o elemento não for encontrado
    return -1;
}

// Implementação da função recursiva para encontrar o último índice
int encontrarUltimaOcorrencia(int vetor[], int inicio, int fim, int valorBuscado, int ordemCrescente, int tamanhoVetor) {
    // Caso base da recursão
    if (fim >= inicio) {
        int meio = inicio + (fim - inicio) / 2;
        
        // Verifica se o elemento do meio é uma ocorrência do valor E se é a ÚLTIMA.
        // A segunda parte da condição verifica se o próximo elemento é maior (ou se é o último elemento do vetor).
        if ((vetor[meio] == valorBuscado) && (meio == tamanhoVetor - 1 || (ordemCrescente ? vetor[meio + 1] > valorBuscado : vetor[meio + 1] < valorBuscado))) {
            return meio; // Encontrou a última ocorrência
        }
        
        // Se o valor buscado for menor que o do meio (em ordem crescente), busca na metade esquerda.
        // Se o valor buscado for maior que o do meio (em ordem decrescente), busca na metade esquerda.
        if (ordemCrescente ? valorBuscado < vetor[meio] : valorBuscado > vetor[meio]) {
            return encontrarUltimaOcorrencia(vetor, inicio, (meio - 1), valorBuscado, ordemCrescente, tamanhoVetor);
        }
        
        // Caso contrário, continua buscando na metade direita (incluindo o caso onde encontramos o valor, mas não é a última ocorrência).
        return encontrarUltimaOcorrencia(vetor, (meio + 1), fim, valorBuscado, ordemCrescente, tamanhoVetor);
    }
    
    // Retorna -1 se o elemento não for encontrado
    return -1;
}