#ifndef PESQUISA_H
#define PESQUISA_H

/**
 * @brief Encontra o índice da primeira ocorrência de um valor em um vetor ordenado.
 * * @param vetor O vetor de inteiros onde a busca será feita.
 * @param inicio O índice inicial da busca.
 * @param fim O índice final da busca.
 * @param valorBuscado O valor a ser encontrado.
 * @param ordemCrescente 1 se o vetor estiver em ordem crescente, 0 se decrescente.
 * @return O índice da primeira ocorrência ou -1 se não for encontrado.
 */
int encontrarPrimeiraOcorrencia(int vetor[], int inicio, int fim, int valorBuscado, int ordemCrescente);

/**
 * @brief Encontra o índice da última ocorrência de um valor em um vetor ordenado.
 * * @param vetor O vetor de inteiros.
 * @param inicio O índice inicial da busca.
 * @param fim O índice final da busca.
 * @param valorBuscado O valor a ser encontrado.
 * @param ordemCrescente 1 se o vetor estiver em ordem crescente, 0 se decrescente.
 * @param tamanhoVetor O tamanho total do vetor.
 * @return O índice da última ocorrência ou -1 se não for encontrado.
 */
int encontrarUltimaOcorrencia(int vetor[], int inicio, int fim, int valorBuscado, int ordemCrescente, int tamanhoVetor);

#endif // PESQUISA_H