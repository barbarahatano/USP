#!/bin/bash

# Compila o programa, mostrando todos os avisos de possíveis erros
echo "Compilando o programa..."
# O comando gcc junta os arquivos .c para criar o executável 'exerc2_main'
gcc main.c pesquisa.c -o exerc2_main -Wall

# Verifica se o comando anterior (compilação) falhou.
# Se falhou, exibe uma mensagem de erro e encerra o script.
if [ $? -ne 0 ]; then
    echo "Erro na compilação."
    exit 1
fi

# A variável especial '$#' conta quantos parâmetros foram passados para o SCRIPT.
# Se o número de parâmetros for 0 (nenhum), executa o teste padrão.
if [ $# -eq 0 ]; then
    echo -e "\n--- Nenhum parâmetro informado. Executando Teste Padrão ---"
    ./exerc2_main

# Se houver 1 ou mais parâmetros, executa o programa C com eles.
else
    echo -e "\n--- Executando com os parâmetros fornecidos via terminal ---"
    # A variável especial '$@' representa TODOS os parâmetros passados para o SCRIPT.
    # O comando abaixo "repasa" os parâmetros para o programa C.
    ./exerc2_main "$@"
fi