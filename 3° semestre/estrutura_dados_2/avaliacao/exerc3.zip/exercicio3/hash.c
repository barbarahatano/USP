#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

// primos para funcao h1
int PRIMOS[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};

// verificar se primo
int eh_primo(int n){

    if (n <= 1) return 0;

    for (int i = 2; i * i <= n; i++){

        if (n % i == 0) return 0;
    }

    return 1;
}

// proximo primo
int proximo_primo(int n){

    while (!eh_primo(n)){

        n++;
    }

    return n;
}






// funcao hash  (h1)
unsigned int h1(unsigned int nusp, int m){

    char nusp_str[11];
    sprintf(nusp_str, "%u", nusp);
    int len = strlen(nusp_str);
    long long soma = 0;

    for (int i = 0; i < len; i++){

        soma += (nusp_str[i] - '0' + 1) * PRIMOS[i];
    }

    unsigned int val = (unsigned int)soma;
    unsigned int p_alta = val >> 16;
    unsigned int p_baixa = val & 0xFFFF;
    val = (p_baixa << 16) | p_alta;

    

    int primeiro_digito = nusp_str[0] - '0';
    unsigned int resultado_xor = primeiro_digito & 1; //primeiro bit do primeiro digito


    for (int i = 1; i < len; i++) {

        int digito_atual = nusp_str[i] - '0';

        if (i % 2 != 0){

            int ultimo_bit = (digito_atual & 8) ? 1 : 0; // bit mais significativo
            resultado_xor ^= ultimo_bit;

        } else {
            
            int primeiro_bit = digito_atual & 1; // bit menos significativo
            resultado_xor ^= primeiro_bit;

        }

    }




    return resultado_xor % m;

}




// funcao hash secundária (h3) para hashing duplo
unsigned int h3(unsigned int nusp, int m){

    return 1 + (nusp % (m - 1));
}

// funcao hash geral que decide entre quadratica e dupla
unsigned int hash_probe(TabelaHash* th, unsigned int nusp, int i){

    if (th->usa_duplo){

        // reespalhamento duplo
        return (h1(nusp, th->tamanho) + i * h3(nusp, th->tamanho)) % th->tamanho;
    } else{

        // reespalhamento quadrático
        return (h1(nusp, th->tamanho) + i * i) % th->tamanho;
    }
}

//gerenciamento

void redimensionar(TabelaHash** th);

TabelaHash* criar_tabela(int tamanho_desejado){
    TabelaHash* th = (TabelaHash*)malloc(sizeof(TabelaHash));
    if (!th){
        return NULL;
    }
    th->tamanho = proximo_primo(tamanho_desejado);
    th->tabela = (Aluno*)calloc(th->tamanho, sizeof(Aluno));
    if (!th->tabela) {
        free(th);
        return NULL;
    }
    th->quantidade = 0;
    th->usa_duplo = 0;
    for (int i = 0; i < th->tamanho; i++) {
        th->tabela[i].ocupado = 0; // 0 = livre
    }
    
    return th;
}

void inserir(TabelaHash** th, Aluno aluno) {

    float fator_carga = (float)((*th)->quantidade + 1) / (*th)->tamanho;

    if (fator_carga > 0.9) {
        redimensionar(th);
    } else if (fator_carga > 0.7 && !(*th)->usa_duplo) {
        (*th)->usa_duplo = 1;
        redimensionar(th); // novo reespalhamento
    }

    int i = 0;
    unsigned int indice;

    do {

        indice = hash_probe(*th, aluno.nusp, i);
        if ((*th)->tabela[indice].ocupado != 1) {
            (*th)->tabela[indice] = aluno;
            (*th)->tabela[indice].ocupado = 1;
            (*th)->quantidade++;

            
            return;
        }

        i++;
    } while (i < (*th)->tamanho);

    //printf("Falha ao inserir aluno %s (NUSP: %u)\n", aluno.nome, aluno.nusp);
}

void redimensionar(TabelaHash** th) {

    TabelaHash* antiga_tabela = *th;
    int novo_tamanho = antiga_tabela->tamanho;

    // se fator de carga > 0.9, dobra o tamanho
    if ((float)antiga_tabela->quantidade / antiga_tabela->tamanho > 0.9){

        novo_tamanho = proximo_primo(antiga_tabela->tamanho * 2);
    }

    TabelaHash* nova_tabela = criar_tabela(novo_tamanho);
    float novo_fator_carga = (float)antiga_tabela->quantidade / nova_tabela->tamanho;
    
    nova_tabela->usa_duplo = (novo_fator_carga > 0.7) ? 1 : 0;
    
    for (int i = 0; i < antiga_tabela->tamanho; i++){

        if (antiga_tabela->tabela[i].ocupado == 1) {
            inserir(&nova_tabela, antiga_tabela->tabela[i]);
        }

    }
    
    liberar_tabela(antiga_tabela);
    *th = nova_tabela;
}


Aluno* buscar(TabelaHash* th, unsigned int nusp) {

    int i = 0;
    unsigned int indice;
    Aluno* encontrado = NULL;

    do {

        indice = hash_probe(th, nusp, i);

        if (th->tabela[indice].ocupado == 1 && th->tabela[indice].nusp == nusp) {
            
            encontrado = &th->tabela[indice];
            return encontrado;
        }

        if (th->tabela[indice].ocupado == 0) { // nao pode estar na frente


            return NULL;
        }
        i++;
    } while (i < th->tamanho);


    return NULL;
}

void remover(TabelaHash* th, unsigned int nusp) {

    int i = 0;

    unsigned int indice;

    do {

        indice = hash_probe(th, nusp, i);

        if (th->tabela[indice].ocupado == 1 && th->tabela[indice].nusp == nusp) {

            th->tabela[indice].ocupado = -1; // removido
            th->quantidade--;
            printf("Sucesso na remocao do aluno com NUSP %u\n", nusp);
            return;
        }
        
        if (th->tabela[indice].ocupado == 0) {

            printf("Falha na remocao: aluno com NUSP %u nao encontrado\n", nusp);
            return;
        }

        i++;

    } while (i < th->tamanho);

    printf("Falha na remocao: aluno com NUSP %u nao encontrado\n", nusp);
}

int salvar_tabela(TabelaHash* th, const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) {
        return 0;
    }

    // salva o cabecalho
    fprintf(f, "%d;%d;%d\n", th->tamanho, th->quantidade, th->usa_duplo);


    for (int i = 0; i < th->tamanho; i++){
        // slot ocupado
        if (th->tabela[i].ocupado == 1) {

            fprintf(f, "%d;1;%u;%s;%s\n", i, th->tabela[i].nusp, th->tabela[i].nome, th->tabela[i].curso);
        }
        // slot removido
        else if (th->tabela[i].ocupado == -1){
            
            fprintf(f, "%d;-1\n", i);
        }
    }

    fclose(f);
    return 1;
}

TabelaHash* carregar_tabela(const char* path){
    FILE* f = fopen(path, "r");
    if (!f) return NULL;

    TabelaHash* th = (TabelaHash*)malloc(sizeof(TabelaHash));
    if (!th) {
        fclose(f);
        return NULL;
    }

    // le cabecalho
    if (fscanf(f, "%d;%d;%d\n", &th->tamanho, &th->quantidade, &th->usa_duplo) != 3) {
        free(th);
        fclose(f);
        return NULL;
    }
    
    // inicializa com ocupado = 0
    th->tabela = (Aluno*)calloc(th->tamanho, sizeof(Aluno));
    if(!th->tabela) {
        free(th);
        fclose(f);
        return NULL;
    }

    int indice;
    char buffer[256]; 

    while (fgets(buffer, sizeof(buffer), f) != NULL) {
        int status_lido;
        
        if (sscanf(buffer, "%d;%d", &indice, &status_lido) == 2) {
            if (status_lido == 1) {
                //slot ocupado
                Aluno a;

                // indice;1;nusp;nome;curso
                sscanf(buffer, "%*d;%*d;%u;%49[^;];%49[^\n]", &a.nusp, a.nome, a.curso);
                a.ocupado = 1;
                th->tabela[indice] = a;
            } else if (status_lido == -1) {
                // slot removido
                th->tabela[indice].ocupado = -1;
            }
        }
    }

    fclose(f);
    return th;
}

void liberar_tabela(TabelaHash* th) {

    if (th) {

        free(th->tabela);
        free(th);
    }

}