#ifndef HASH_H
#define HASH_H

//print de sucessso/falha no main, menos funcao remover

typedef struct {
    unsigned int nusp;
    char nome[50];
    char curso[50];
    int ocupado; // 1,0,-1
} Aluno;


typedef struct {
    Aluno* tabela;
    int tamanho;
    int quantidade;
    int usa_duplo;
} TabelaHash;


TabelaHash* criar_tabela(int tamanho_desejado);

void inserir(TabelaHash** th, Aluno aluno);

Aluno* buscar(TabelaHash* th, unsigned int nusp);

void remover(TabelaHash* th, unsigned int nusp);

int salvar_tabela(TabelaHash* th, const char* path);

TabelaHash* carregar_tabela(const char* path);

void liberar_tabela(TabelaHash* th);

#endif