#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

void teste_automatico() {
    //printf("teste automatico\n");

    //passo 1 do pdf (criar tabela hash de tamanho 11)
    //printf("\ncriando tabela\n");
    TabelaHash* th = criar_tabela(11);

    if (th){
        printf("Sucesso ao criar tabela\n");
    } else{
        printf("Falha ao criar tabela\n");
    }
    //printf("sucesso\n");

    // passo 2 do pdf (inserir 5 alunos)
    //printf("\ninserindo alunos\n");
    Aluno alunos[5] = {
        {45235987, "Artur Azevedo", "Engenharia Civil", 1},
        {32654895, "Joao Seila", "Ciencia da Computacao", 1},
        {16523489, "Ricardo Naosei", "Fisica", 1},
        {24658974, "Adamastor Qualquercoisa", "Letras", 1},
        {12653498, "Miguel Criatividade", "Pedagogia", 1}
    };
    for (int i = 0; i < 5; i++) {
        inserir(&th, alunos[i]);

        printf("Sucesso ao inserir aluno %s (NUSP: %u)\n", alunos[i].nome, alunos[i].nusp);
    }

    // passo 3 do pdf (remover dados de dois alunos)
    remover(th, 45235987);
    remover(th, 32654895);

    // passo 4 (salvar a tabela)
    
    int salvou = salvar_tabela(th, "hash.txt");
    if(salvou){
        printf("Sucesso ao salvar tabela\n");
    } else {
        printf("Falha ao salvar tabela\n");
    }
    //liberar da alocacao ja que esta no txt
    liberar_tabela(th);

    // passo 5 (carregar a tabela e buscar alunos)
    th = carregar_tabela("hash.txt");
    if(th) {

        //busca 2 cadastrados e 1 nao
        unsigned int nusps_busca[] = {12653498, 24658974, 55555555};
        for (int i = 0; i < 3; i++) {
            Aluno* encontrado = buscar(th, nusps_busca[i]);

            if (encontrado) {
                printf("NUSP: %u, Nome: %s, Curso: %s\n", encontrado->nusp, encontrado->nome, encontrado->curso);
            } else {
                printf("Chave %u nao foi encontrada\n", nusps_busca[i]);
            }


        }
        liberar_tabela(th);
    } else {
        printf("Falha ao carregar tabela\n");
    }
    //fim dos testes
}


int main(int argc, char* argv[]) {

    //teste automatico
    if (argc < 2) {
        teste_automatico();
        return 0;
    }

    
    char* comando = argv[1];

    //comando criar
    if (strcmp(comando, "criar") == 0 && argc == 4) {
        int tamanho = atoi(argv[2]);
        char* path = argv[3];
        TabelaHash* th = criar_tabela(tamanho);

        if(th){
            printf("Sucesso ao criar tabela\n");
        } else{
            printf("Falha ao criar tabela\n");
        }
        
        if(salvar_tabela(th, path)){
            printf("Sucesso ao salvar tabela\n");
        } else {
            printf("Falha ao salvar tabela\n");
        }

        liberar_tabela(th);

    //comando inserir
    } else if (strcmp(comando, "inserir") == 0 && argc > 3) {
        char* path = argv[2];
        TabelaHash* th = carregar_tabela(path);
        if (!th) {
            printf("Falha ao carregar a tabela\n");
            return 1;
        }

        for (int i = 3; i < argc; i++) {
            Aluno a;
            char* token;
            char* str_aluno = argv[i];

            token = strtok(str_aluno, ","); a.nusp = (unsigned int)atol(token);
            token = strtok(NULL, ","); strncpy(a.nome, token, 49); a.nome[49] = '\0';
            token = strtok(NULL, ","); strncpy(a.curso, token, 49); a.curso[49] = '\0';
            a.ocupado = 1;

            inserir(&th, a);
            printf("Sucesso ao inserir aluno %s (NUSP: %u)\n", a.nome, a.nusp);
        }

        if (salvar_tabela(th, path)) {
             printf("Tabela atualizada\n");
        } else {
             printf("Nao foi possivel salvar a tabela atualizada.\n");
        }
        liberar_tabela(th);

    } else if (strcmp(comando, "buscar") == 0 && argc > 3) {
        char* path = argv[2];
        TabelaHash* th = carregar_tabela(path);
         if (!th) {
            printf("Falha ao carregar a tabela\n");
            return 1;
        }
        for (int i = 3; i < argc; i++) {
            unsigned int nusp = (unsigned int)atol(argv[i]);
            Aluno* encontrado = buscar(th, nusp);
            if (encontrado) {
                printf("NUSP: %u, Nome: %s, Curso: %s\n", encontrado->nusp, encontrado->nome, encontrado->curso);
            } else {
                printf("Chave %u nao foi encontrada\n", nusp);
            }
        }
        liberar_tabela(th);

    } else if (strcmp(comando, "remover") == 0 && argc > 3) {
        char* path = argv[2];
        TabelaHash* th = carregar_tabela(path);
         if (!th) {
            printf("Falha ao carregar a tabela\n");
            return 1;
        }
        for (int i = 3; i < argc; i++) {
            unsigned int nusp = (unsigned int)atol(argv[i]);
            remover(th, nusp);
        }
         if (salvar_tabela(th, path)) {
             printf("Sucesso: Tabela atualizada e salva em %s.\n", path);
        } else {
             printf("Fracasso: Nao foi possivel salvar a tabela atualizada.\n");
        }
        liberar_tabela(th);
    } else {
        printf("Comando invalido ou argumentos insuficientes.\n");
    }

    return 0;
}