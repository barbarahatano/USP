#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

// --- Funções Auxiliares (estáticas, visíveis apenas neste arquivo) ---

// Função para verificar se um número é primo
static int ehPrimo(int numero) {
    if (numero <= 1) return 0;
    for (int i = 2; i * i <= numero; i++) {
        if (numero % i == 0) return 0;
    }
    return 1;
}

// Função para encontrar o próximo número primo a partir de 'n'
static int proximoPrimo(int numero) {
    while (!ehPrimo(numero)) {
        numero++;
    }
    return numero;
}

// Função que aplica uma rotação de 13 bits à esquerda em um valor de 32 bits
static unsigned int rotacionarEsquerda13(unsigned int valor) {
    return (valor << 13) | (valor >> (32 - 13));
}

// --- Função Hash Principal ---

// Implementa a função hash customizada usando o nome como chave
static unsigned int funcaoHash(const char* chave, int tamanho) {
    unsigned int h1 = 0;
    
    // Passo 1: Soma dos valores ASCII com deslocamento de bits
    for (int i = 0; chave[i] != '\0'; i++) {
        h1 += (unsigned int)chave[i] << (i % 8);
    }
    
    // Passo 2: Aplica a rotação de 13 bits no resultado
    h1 = rotacionarEsquerda13(h1);

    // Passo 3: Retorna o resultado módulo o tamanho da tabela para obter o índice
    return h1 % tamanho;
}

// --- Implementação das Funções de Manipulação da Tabela ---

// Cria uma tabela hash, ajustando o tamanho para o próximo número primo
TabelaHash* criarTabela(int tamanho) {
    TabelaHash* th = (TabelaHash*)malloc(sizeof(TabelaHash));
    th->tamanho = proximoPrimo(tamanho);
    
    // Aloca a tabela (vetor de ponteiros)
    th->tabela = (NoAluno**)malloc(th->tamanho * sizeof(NoAluno*));
    
    // Inicializa todas as posições com NULL para indicar que estão vazias
    for (int i = 0; i < th->tamanho; i++) {
        th->tabela[i] = NULL;
    }
    
    return th;
}

// Libera toda a memória alocada para a tabela e seus nós
void liberarTabela(TabelaHash* th) {
    if (!th) return;
    
    // Itera sobre cada posição da tabela
    for (int i = 0; i < th->tamanho; i++) {
        NoAluno* atual = th->tabela[i];
        // Percorre a lista de colisões, liberando cada nó
        while (atual != NULL) {
            NoAluno* temporario = atual;
            atual = atual->proximo;
            free(temporario);
        }
    }
    free(th->tabela); // Libera o vetor de ponteiros
    free(th);      // Libera a estrutura principal da tabela
}

// Insere um novo aluno na tabela hash
void inserirAluno(TabelaHash* th, const char* nome, unsigned int nusp, const char* curso) {
    // Calcula o índice onde o aluno será inserido
    unsigned int indice = funcaoHash(nome, th->tamanho);
    
    // Aloca memória para o novo nó do aluno
    NoAluno* novoNo = (NoAluno*)malloc(sizeof(NoAluno));
    strcpy(novoNo->nome, nome);
    novoNo->nusp = nusp;
    strcpy(novoNo->curso, curso);
    
    // Adiciona o novo nó no início da lista (estratégia de encadeamento simples)
    novoNo->proximo = th->tabela[indice];
    th->tabela[indice] = novoNo;
}

// Busca um aluno pelo nome
NoAluno* buscarAluno(TabelaHash* th, const char* nome) {
    unsigned int indice = funcaoHash(nome, th->tamanho);
    NoAluno* atual = th->tabela[indice];
    
    // Percorre a lista ligada no índice calculado
    while (atual != NULL) {
        if (strcmp(atual->nome, nome) == 0) {
            return atual; // Retorna o nó se encontrou o nome
        }
        atual = atual->proximo;
    }
    
    return NULL; // Retorna NULL se não encontrou
}

// Remove um aluno da tabela pelo nome
void removerAluno(TabelaHash* th, const char* nome) {
    unsigned int indice = funcaoHash(nome, th->tamanho);
    NoAluno* atual = th->tabela[indice];
    NoAluno* anterior = NULL;

    // Percorre a lista procurando pelo nó a ser removido
    while (atual != NULL && strcmp(atual->nome, nome) != 0) {
        anterior = atual;
        atual = atual->proximo;
    }
    
    // Se 'atual' é NULL, o aluno não foi encontrado
    if (atual == NULL) {
        return;
    }
    
    // Caso 1: O nó a ser removido é o primeiro da lista
    if (anterior == NULL) {
        th->tabela[indice] = atual->proximo;
    } 
    // Caso 2: O nó está no meio ou no fim da lista
    else {
        anterior->proximo = atual->proximo;
    }
    
    free(atual); // Libera a memória do nó removido
}


// --- Implementação das Funções de Arquivo ---

// Salva o conteúdo da tabela em um arquivo
void salvarTabela(TabelaHash* th, const char* caminho) {
    FILE* arquivo = fopen(caminho, "w");
    if (!arquivo) {
        perror("Erro ao abrir arquivo para escrita");
        return;
    }
    
    // Salva o tamanho da tabela na primeira linha para facilitar o carregamento
    fprintf(arquivo, "%d\n", th->tamanho);
    
    // Percorre cada posição da tabela
    for (int i = 0; i < th->tamanho; i++) {
        NoAluno* atual = th->tabela[i];
        // Percorre a lista de colisões, salvando cada aluno na mesma linha
        while (atual != NULL) {
            fprintf(arquivo, "%s:%u:%s;", atual->nome, atual->nusp, atual->curso);
            atual = atual->proximo;
        }
        fprintf(arquivo, "\n"); // Pula para a próxima linha para o próximo índice
    }
    
    fclose(arquivo);
}

// Carrega uma tabela a partir de um arquivo
TabelaHash* carregarTabela(const char* caminho) {
    FILE* arquivo = fopen(caminho, "r");
    if (!arquivo) {
        // Se o arquivo não existe, retorna NULL
        return NULL;
    }

    int tamanho;
    fscanf(arquivo, "%d\n", &tamanho); // Lê o tamanho da tabela

    // Cria uma tabela com o tamanho exato lido do arquivo
    TabelaHash* th = (TabelaHash*)malloc(sizeof(TabelaHash));
    th->tamanho = tamanho;
    th->tabela = (NoAluno**)calloc(tamanho, sizeof(NoAluno*));

    char linha[2048]; // Buffer para ler cada linha do arquivo
    for (int i = 0; i < tamanho; i++) {
        if (fgets(linha, sizeof(linha), arquivo)) {
            // Usa strtok para separar múltiplos alunos na mesma linha (delimitador ';')
            char* registro = strtok(linha, ";\n");
            while (registro != NULL) {
                char nome[100];
                unsigned int nusp;
                char curso[100];

                // Usa sscanf para extrair os dados de cada aluno (delimitador ':')
                sscanf(registro, "%99[^:]:%u:%99s", nome, &nusp, curso);
                inserirAluno(th, nome, nusp, curso);
                
                registro = strtok(NULL, ";\n");
            }
        }
    }

    fclose(arquivo);
    return th;
}