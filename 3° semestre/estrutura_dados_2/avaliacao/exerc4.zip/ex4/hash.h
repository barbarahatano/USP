#ifndef HASH_H
#define HASH_H

// Estrutura para representar um nó na lista de alunos (para tratar colisões)
typedef struct NoAluno {
    char nome[50];
    unsigned int nusp;
    char curso[50];
    struct NoAluno* proximo; // Ponteiro para o próximo aluno no mesmo índice da tabela
} NoAluno;

// Estrutura principal da Tabela Hash
typedef struct {
    NoAluno** tabela; // A tabela é um vetor de ponteiros para nós de alunos
    int tamanho;      // O tamanho total da tabela
} TabelaHash;

// --- Protótipos das Funções ---

// Aloca memória e inicializa uma nova tabela hash
TabelaHash* criarTabela(int tamanho);

// Insere os dados de um aluno na tabela
void inserirAluno(TabelaHash* th, const char* nome, unsigned int nusp, const char* curso);

// Busca por um aluno na tabela usando o nome como chave
NoAluno* buscarAluno(TabelaHash* th, const char* nome);

// Remove um aluno da tabela usando o nome como chave
void removerAluno(TabelaHash* th, const char* nome);

// Salva o conteúdo da tabela hash em um arquivo de texto
void salvarTabela(TabelaHash* th, const char* caminho);

// Carrega os dados de um arquivo de texto para uma tabela hash
TabelaHash* carregarTabela(const char* caminho);

// Libera toda a memória alocada pela tabela hash
void liberarTabela(TabelaHash* th);

#endif // HASH_H