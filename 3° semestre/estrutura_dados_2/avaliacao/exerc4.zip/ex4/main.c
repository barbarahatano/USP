#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

// Protótipo da função de teste
void executarTestePadrao();

int main(int argc, char *argv[]) {
    // Se nenhum parâmetro for passado, executa a rotina de teste padrão
    if (argc == 1) {
        executarTestePadrao();
        return 0;
    }

    // --- Tratamento dos Comandos da Linha de Comando ---

    char* comando = argv[1];

    // Comando: criar <tamanho> <caminho_arquivo>
    if (strcmp(comando, "criar") == 0) {
        if (argc != 4) {
            printf("Uso incorreto. Formato: ./main criar <tamanho> <caminho>\n");
            return 1;
        }
        int tamanho = atoi(argv[2]);
        char* caminho = argv[3];
        
        TabelaHash* th = criarTabela(tamanho);
        if (th) {
            salvarTabela(th, caminho);
            printf("Sucesso: Tabela criada e salva em '%s'.\n", caminho);
            liberarTabela(th);
        } else {
            printf("Falha: Nao foi possivel criar a tabela.\n");
        }
    }
    // Comando: inserir <caminho_arquivo> <nome>:<nusp>:<curso> ...
    else if (strcmp(comando, "inserir") == 0) {
        if (argc < 4) {
            printf("Uso incorreto. Formato: ./main inserir <caminho> <nome1>:<nusp1>:<curso1> ...\n");
            return 1;
        }
        char* caminho = argv[2];
        TabelaHash* th = carregarTabela(caminho);
        if (!th) {
            printf("Falha: Arquivo da tabela '%s' nao encontrado. Crie a tabela primeiro.\n", caminho);
            return 1;
        }

        // Itera sobre todos os argumentos de alunos a serem inseridos
        for (int i = 3; i < argc; i++) {
            char nome[100];
            unsigned int nusp;
            char curso[100];
            
            // Analisa a string "nome:nusp:curso"
            if (sscanf(argv[i], "%99[^:]:%u:%99s", nome, &nusp, curso) == 3) {
                 inserirAluno(th, nome, nusp, curso);
            }
        }
        salvarTabela(th, caminho);
        printf("Sucesso: Alunos inseridos e tabela salva em '%s'.\n", caminho);
        liberarTabela(th);
    }
    // Comando: buscar <caminho_arquivo> <nome1> <nome2> ...
    else if (strcmp(comando, "buscar") == 0) {
         if (argc < 4) {
            printf("Uso incorreto. Formato: ./main buscar <caminho> <nome1> <nome2> ...\n");
            return 1;
        }
        char* caminho = argv[2];
        TabelaHash* th = carregarTabela(caminho);
        if (!th) {
            printf("Falha: Arquivo da tabela '%s' nao encontrado.\n", caminho);
            return 1;
        }

        // Itera sobre todos os nomes a serem buscados
        for (int i = 3; i < argc; i++) {
            char* nomeParaBuscar = argv[i];
            NoAluno* encontrado = buscarAluno(th, nomeParaBuscar);
            if (encontrado) {
                printf("Encontrado -> Nome: %s, NUSP: %u, Curso: %s\n", encontrado->nome, encontrado->nusp, encontrado->curso);
            } else {
                printf("Ausencia -> Aluno com nome '%s' nao encontrado.\n", nomeParaBuscar);
            }
        }
        liberarTabela(th);
    }
    // Comando: remover <caminho_arquivo> <nome1> <nome2> ...
    else if (strcmp(comando, "remover") == 0) {
         if (argc < 4) {
            printf("Uso incorreto. Formato: ./main remover <caminho> <nome1> <nome2> ...\n");
            return 1;
        }
        char* caminho = argv[2];
        TabelaHash* th = carregarTabela(caminho);
        if (!th) {
            printf("Falha: Arquivo da tabela '%s' nao encontrado.\n", caminho);
            return 1;
        }
        
        // Itera sobre todos os nomes a serem removidos
        for (int i = 3; i < argc; i++) {
            removerAluno(th, argv[i]);
        }
        salvarTabela(th, caminho);
        printf("Sucesso: Operacao de remocao concluida e tabela salva em '%s'.\n", caminho);
        liberarTabela(th);
    }
    // Comando inválido
    else {
        printf("Comando '%s' invalido.\n", comando);
        printf("Comandos disponiveis: criar, inserir, buscar, remover\n");
    }

    return 0;
}

/**
 * @brief Executa a sequência de testes padrão quando nenhum parâmetro é fornecido.
 */
void executarTestePadrao() {
    printf("--- Executando Teste Padrao ---\n\n");
    const char* caminhoArquivo = "hash_nome.txt";

    // 1. Criar uma tabela hash com tamanho 11
    printf("1. Criando tabela com tamanho 11...\n");
    TabelaHash* th = criarTabela(11);
    printf("Tabela criada com sucesso (tamanho real primo: %d).\n\n", th->tamanho);

    // 2. Inserir cinco alunos com nomes distintos
    printf("2. Inserindo 5 alunos...\n");
    inserirAluno(th, "Ana Silva", 123456, "BCC");
    inserirAluno(th, "Joao Souza", 234567, "EngComp");
    inserirAluno(th, "Maria Luiza", 345678, "Estatistica");
    inserirAluno(th, "Carlos Dias", 456789, "BCC");
    inserirAluno(th, "Pedro Alves", 567890, "Sistemas");
    printf("Alunos inseridos com sucesso.\n\n");

    // 3. Remover dois deles
    printf("3. Removendo 2 alunos (Joao Souza e Carlos Dias)...\n");
    removerAluno(th, "Joao Souza");
    removerAluno(th, "Carlos Dias");
    printf("Alunos removidos com sucesso.\n\n");

    // 4. Salvar a tabela no diretório raiz
    printf("4. Salvando tabela em '%s'...\n", caminhoArquivo);
    salvarTabela(th, caminhoArquivo);
    printf("Tabela salva com sucesso.\n\n");
    liberarTabela(th); // Libera a tabela da memória

    // 5. Carregar a tabela e fazer buscas
    printf("5. Carregando tabela e buscando alunos...\n");
    th = carregarTabela(caminhoArquivo);
    if (!th) {
        printf("Falha ao carregar a tabela para o teste de busca.\n");
        return;
    }

    const char* nomesParaBuscar[] = {"Ana Silva", "Pedro Alves", "Joao Souza"};
    for (int i = 0; i < 3; i++) {
        printf("Buscando por '%s': ", nomesParaBuscar[i]);
        NoAluno* encontrado = buscarAluno(th, nomesParaBuscar[i]);
        if (encontrado) {
            printf("Encontrado [Nome: %s, NUSP: %u, Curso: %s]\n", encontrado->nome, encontrado->nusp, encontrado->curso);
        } else {
            printf("Nao encontrado.\n");
        }
    }
    
    liberarTabela(th);
    printf("\n--- Teste Padrao Concluido ---\n");
}