#!/bin/bash

# Limpa a tela para uma saída mais organizada
clear

echo "=== Compilando o programa do Exercício 4 ==="

# Comando de compilação que inclui TODOS os arquivos .c necessários:
# main.c (com a lógica de comandos) e hashtable.c (com a implementação da tabela)
gcc main.c hash.c -o exerc4_main -Wall

# Verifica se a compilação falhou e encerra o script se houver erro
if [ $? -ne 0 ]; then
    echo -e "\n>>> Erro na compilação. Verifique as mensagens acima. <<<"
    exit 1
fi

echo -e "\nCompilação concluída com sucesso!"
echo "================================================"


# --- Lógica de Execução ---

# Se o script for chamado sem nenhum parâmetro ($# -eq 0),
# ele executa o programa C sem parâmetros, o que aciona o teste padrão.
if [ $# -eq 0 ]; then
    echo -e "\n--- Executando Teste Padrão (nenhum parâmetro fornecido) ---"
    ./exerc4_main

# Se houver parâmetros, o script os repassa para o programa C.
else
    echo -e "\n--- Executando com os parâmetros fornecidos via terminal ---"
    # A variável especial "$@" representa todos os parâmetros que o script recebeu.
    ./exerc4_main "$@"
fi

echo -e "\nScript finalizado."