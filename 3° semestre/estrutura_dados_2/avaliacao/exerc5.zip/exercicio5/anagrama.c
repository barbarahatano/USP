#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "anagrama.h"

// funcoes auxiliares

void tudo_minusculo(char *str) {
    for (int i = 0; str[i] != '\0'; i++) {

        // verifica se maiusculo
        if (str[i] >= 'A' && str[i] <= 'Z') {

            // converte pra minusculo
            str[i] = str[i] + ('a' - 'A');
        }
    }
}

int busca_binaria(char array[], char item, int low, int high){

    if (high <= low) {
        return (item > array[low]) ? (low + 1) : low;
    }

    int mid = (low + high) / 2;

    if (item == array[mid]) {
        return mid + 1;
    }

    if (item > array[mid]) {
        return busca_binaria(array, item, mid + 1, high);
    }

    return busca_binaria(array, item, low, mid - 1);
}

void insertion_sort_binario(char array[]) {
    
    // ordena o array usando o algoritmo de insercao com busca binaria
    
    int n = strlen(array);

    for (int i = 1; i < n; ++i) {

        char chave = array[i];
        int j = i - 1;
        int pos = busca_binaria(array, chave, 0, j);

        while (j >= pos) {
            
            array[j + 1] = array[j];
            j--;
        }

        array[j + 1] = chave;
    }
}

// funcao usada em main

void verificar_anagrama(char *palavra1, char *palavra2) {
    char p1[100], p2[100];
    strcpy(p1, palavra1);
    strcpy(p2, palavra2);

    tudo_minusculo(p1);
    tudo_minusculo(p2);

    // checar se tem o mesmo comprimento
    if (strlen(p1) != strlen(p2)) {
        printf("Palavra 1: %s - Palavra 2: %s - Anagrama? nao\n", palavra1, palavra2);
        return;
    }

    insertion_sort_binario(p1);
    insertion_sort_binario(p2);

    char *resultado = (strcmp(p1, p2) == 0) ? "sim" : "nao";
    printf("Palavra 1: %s - Palavra 2: %s - Anagrama ? %s\n", palavra1, palavra2, resultado);
}