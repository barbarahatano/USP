#ifndef ANAGRAMA_H
#define ANAGRAMA_H

void verificar_anagrama(char *palavra1, char *palavra2);

#endif