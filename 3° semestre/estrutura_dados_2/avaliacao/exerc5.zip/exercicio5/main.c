#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "anagrama.h"


int main(int argc, char *argv[]) {


    
    // passou palavras como parametros
    if (argc == 3) {
        verificar_anagrama(argv[1], argv[2]);



    } else {  //teste automatico
        
        verificar_anagrama("Pedro", "poder");
        verificar_anagrama("Brasil", "brasileiro");
    }

    return 0;
}