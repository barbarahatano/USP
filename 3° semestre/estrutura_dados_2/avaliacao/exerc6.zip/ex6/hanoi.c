#include <stdio.h>
#include "hanoi.h"

void resolverTorresDeHanoi(int numDiscos, int pesos[], char torreOrigem, char torreDestino, char torreAuxiliar, int* contadorMovimentos, long long* pesoTotalMovido) {
    // Caso base da recursão: se não há discos para mover, retorna.
    if (numDiscos <= 0) {
        return;
    }
    
    // Passo 1: Mover recursivamente N-1 discos da torre de Origem para a Auxiliar,
    // usando a de Destino como passagem.
    resolverTorresDeHanoi(numDiscos - 1, pesos, torreOrigem, torreAuxiliar, torreDestino, contadorMovimentos, pesoTotalMovido);
    
    // Passo 2: Mover o disco N (o maior que restou na origem) da Origem para o Destino.
    int indiceDisco = numDiscos - 1;
    int pesoDisco = pesos[indiceDisco];
    
    // Imprime os detalhes do movimento atual.
    printf("Mover disco %d (peso %d) da torre %c para %c\n", indiceDisco, pesoDisco, torreOrigem, torreDestino);
    
    // Atualiza os contadores totais.
    (*contadorMovimentos)++;
    (*pesoTotalMovido) += pesoDisco;
    
    // Passo 3: Mover recursivamente os N-1 discos da torre Auxiliar para a de Destino,
    // usando a de Origem como passagem.
    resolverTorresDeHanoi(numDiscos - 1, pesos, torreAuxiliar, torreDestino, torreOrigem, contadorMovimentos, pesoTotalMovido);
}