#ifndef HANOI_H
#define HANOI_H

/**
 * @brief Resolve o problema das Torres de Hanói de forma recursiva.
 * * @param numDiscos Número de discos a serem movidos.
 * @param pesos Vetor com os pesos dos discos (já ordenado).
 * @param torreOrigem Caractere que representa a torre de origem (ex: 'A').
 * @param torreDestino Caractere que representa a torre de destino (ex: 'C').
 * @param torreAuxiliar Caractere que representa a torre auxiliar (ex: 'B').
 * @param contadorMovimentos Ponteiro para a variável que conta os movimentos.
 * @param pesoTotalMovido Ponteiro para a variável que acumula o peso.
 */
void resolverTorresDeHanoi(int numDiscos, int pesos[], char torreOrigem, char torreDestino, char torreAuxiliar, int* contadorMovimentos, long long* pesoTotalMovido);

#endif // HANOI_H