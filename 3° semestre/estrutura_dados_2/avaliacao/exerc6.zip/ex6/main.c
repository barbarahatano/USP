#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sorting.h"
#include "hanoi.h"

void executarTesteHanoi(const char* algoritmo, int pesos[], int numDiscos);

int main(int argc, char* argv[]) {
    // Se nenhum parâmetro for passado, executa os testes padrão
    if (argc == 1) {
        printf("Nenhum parametro informado. Executando testes padrao.\n\n");
        int pesosTeste1[] = {8, 1, 5};
        executarTesteHanoi("quick", pesosTeste1, 3);
        
        printf("\n-----------------------------------\n\n");

        int pesosTeste2[] = {3, 9, 2, 4};
        executarTesteHanoi("heap", pesosTeste2, 4);
    } 
    // Se houver parâmetros, executa com os dados fornecidos
    else if (argc > 2) {
        const char* algoritmo = argv[1];
        if (strcmp(algoritmo, "quick") != 0 && strcmp(algoritmo, "heap") != 0) {
            printf("Erro: algoritmo de ordenacao '%s' invalido. Use 'quick' ou 'heap'.\n", algoritmo);
            return 1;
        }

        int numDiscos = argc - 2;
        int* pesos = (int*)malloc(numDiscos * sizeof(int));
        for (int i = 0; i < numDiscos; i++) {
            pesos[i] = atoi(argv[i + 2]); // Converte os pesos de string para inteiro
        }
        
        executarTesteHanoi(algoritmo, pesos, numDiscos);
        free(pesos); // Libera a memória alocada para os pesos
    } else {
        printf("Uso incorreto.\n");
        printf("Modo 1 (padrão): ./exerc6_main\n");
        printf("Modo 2 (parâmetros): ./exerc6_main <algoritmo> <peso1> <peso2> ...\n");
    }

    return 0;
}

// Função auxiliar para organizar e executar um teste completo
void executarTesteHanoi(const char* algoritmo, int pesos[], int numDiscos) {
    printf("--- Iniciando teste com %s ---\n", algoritmo);

    // 1. Ordena os pesos com o algoritmo escolhido
    printf("Ordenacao utilizada: %s\n", algoritmo);
    if (strcmp(algoritmo, "quick") == 0) {
        ordenarPorQuickSort(pesos, 0, numDiscos - 1);
    } else {
        ordenarPorHeapSort(pesos, numDiscos);
    }
    
    printf("Pesos ordenados: ");
    for(int i=0; i<numDiscos; i++) printf("%d ", pesos[i]);
    printf("\n\nSequencia de movimentos:\n");

    // 2. Resolve Hanói e calcula os totais
    int contadorMovimentos = 0;
    long long pesoTotalMovido = 0;
    resolverTorresDeHanoi(numDiscos, pesos, 'A', 'C', 'B', &contadorMovimentos, &pesoTotalMovido);

    // 3. Imprime os resultados finais
    printf("\nNumero total de movimentos: %d\n", contadorMovimentos);
    printf("Carga total movimentada: %lld\n", pesoTotalMovido);
    printf("--- Fim do teste ---\n");
}