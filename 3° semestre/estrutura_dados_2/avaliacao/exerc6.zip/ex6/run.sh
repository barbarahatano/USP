#!/bin/bash

clear
echo "=== Compilando o programa do Exercício 6 ==="

# O comando de compilação DEVE incluir todos os arquivos .c
gcc main.c sorting.c hanoi.c -o exerc6_main -Wall

# Verifica se a compilação falhou
if [ $? -ne 0 ]; then
    echo -e "\n>>> Erro na compilação. <<<"
    exit 1
fi

echo -e "\nCompilação concluída com sucesso!"
echo "================================================"

# Se o script for chamado sem parâmetros, executa o programa no modo padrão
if [ $# -eq 0 ]; then
    echo -e "\n--- Executando Teste Padrão (sem parâmetros) ---"
    ./exerc6_main

# Se houver parâmetros, o script os repassa para o programa C
else
    echo -e "\n--- Executando com os parâmetros fornecidos ---"
    ./exerc6_main "$@"
fi

echo -e "\nScript finalizado."