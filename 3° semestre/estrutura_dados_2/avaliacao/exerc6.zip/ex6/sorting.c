#include "sorting.h"

// --- Funções Auxiliares ---

// Função auxiliar para trocar dois números de posição
static void trocar(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}


// --- Lógica do Quicksort ---

// Função para particionar o vetor e encontrar a posição do pivô
static int particionar(int vetor[], int inicio, int fim) {
    int pivo = vetor[fim]; // O pivô é o último elemento
    int i = (inicio - 1);

    for (int j = inicio; j <= fim - 1; j++) {
        if (vetor[j] < pivo) {
            i++;
            trocar(&vetor[i], &vetor[j]);
        }
    }
    trocar(&vetor[i + 1], &vetor[fim]);
    return (i + 1);
}

// Função principal, recursiva, do Quicksort
void ordenarPorQuickSort(int vetor[], int inicio, int fim) {
    if (inicio < fim) {
        // Encontra o índice do pivô
        int indicePivo = particionar(vetor, inicio, fim);
        // Ordena recursivamente as duas metades (antes e depois do pivô)
        ordenarPorQuickSort(vetor, inicio, indicePivo - 1);
        ordenarPorQuickSort(vetor, indicePivo + 1, fim);
    }
}


// --- Lógica do Heapsort ---

// Função recursiva para transformar um sub-vetor em um Max-Heap
static void maxHeapify(int vetor[], int tamanho, int indiceRaiz) {
    int maior = indiceRaiz;
    int esquerda = 2 * indiceRaiz + 1;
    int direita = 2 * indiceRaiz + 2;

    // Se o filho da esquerda for maior que a raiz
    if (esquerda < tamanho && vetor[esquerda] > vetor[maior])
        maior = esquerda;

    // Se o filho da direita for maior que o maior até agora
    if (direita < tamanho && vetor[direita] > vetor[maior])
        maior = direita;

    // Se o maior elemento não for a raiz, troca e continua a recursão
    if (maior != indiceRaiz) {
        trocar(&vetor[indiceRaiz], &vetor[maior]);
        maxHeapify(vetor, tamanho, maior);
    }
}

// Função principal do Heapsort
void ordenarPorHeapSort(int vetor[], int tamanho) {
    // 1. Constrói o Max-Heap (organiza o vetor)
    for (int i = tamanho / 2 - 1; i >= 0; i--)
        maxHeapify(vetor, tamanho, i);

    // 2. Extrai um por um os elementos do heap
    for (int i = tamanho - 1; i > 0; i--) {
        // Move a raiz atual (maior elemento) para o fim
        trocar(&vetor[0], &vetor[i]);
        // Chama maxHeapify na heap reduzida para reorganizar
        maxHeapify(vetor, i, 0);
    }
}