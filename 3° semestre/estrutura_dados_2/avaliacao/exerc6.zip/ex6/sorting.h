#ifndef SORTING_H
#define SORTING_H

/**
 * @brief Ordena um vetor usando o algoritmo Quicksort.
 * @param vetor O vetor a ser ordenado.
 * @param inicio O índice inicial do vetor/sub-vetor.
 * @param fim O índice final do vetor/sub-vetor.
 */
void ordenarPorQuickSort(int vetor[], int inicio, int fim);

/**
 * @brief Ordena um vetor usando o algoritmo Heapsort.
 * @param vetor O vetor a ser ordenado.
 * @param tamanho O número de elementos no vetor.
 */
void ordenarPorHeapSort(int vetor[], int tamanho);

#endif // SORTING_H