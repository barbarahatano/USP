#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "nrainhas.h"

int main(int argc, char *argv[]) {

    // verifica se passou argumento
    if (argc > 1) {
        int n = atoi(argv[1]);
        n_rainhas(n);

    } else { // teste automatico
 
        
        // teste 1
        n_rainhas(4);
        
        printf("\n");

        // teste 2
        n_rainhas(8);
    }

    return 0;
}