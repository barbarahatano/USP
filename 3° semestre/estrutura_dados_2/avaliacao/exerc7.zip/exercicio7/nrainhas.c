#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "nrainhas.h"

// tamanho maximo, acima disso começa a ficar inviavel
#define MAX_N 14
// Maximum number of distinct solutions to store.
#define MAXIMO_SOLUCOES 40000

int chamadas_recursivas;
int contagem_solucoes;

int solucoes[MAXIMO_SOLUCOES][MAX_N];


// declaracao das funcoes auxiliares
void backtrack(int col, int n, int tabuleiro[MAX_N], int linhas_ocupadas[MAX_N], int diagonais1_ocupadas[2 * MAX_N - 1], int diagonais2_ocupadas[2 * MAX_N - 1]);
void processar_solucao(int n, const int tabuleiro[MAX_N]);
void gerar_simetrias(int n, const int* original, int simetrias[8][MAX_N]);
void forma_canonica(int n, int simetrias[8][MAX_N], int tabuleiro_canonico[MAX_N]);
int solucao_ja_contabilizada(int n, const int tabuleiro[MAX_N]);
void add_solucao(int n, const int tabuleiro[MAX_N]);
void printar_solucao(int n, const int tabuleiro[MAX_N]);


void n_rainhas(int N) {

    // checa possibilidade de usar o N
    if (N <= 0 || N > MAX_N) {
        if(N > 0) printf("Erro: tamanho N=%d comeca a ser inviavel (maximo: %d).\n", N, MAX_N);
        else printf("Erro: tamanho invalido\n");
        return;
    }

    // resetar
    chamadas_recursivas = 0;
    contagem_solucoes = 0;

 
    // tabuleiro[coluna] = linha (que a rainha esta)
    int tabuleiro[MAX_N];

    // checar linhas e diagonais ocupadas
    int linhas_ocupadas[MAX_N] = {0};
    int diagonais1_ocupadas[2 * MAX_N - 1] = {0}; // diagonais (linha + coluna)
    int diagonais2_ocupadas[2 * MAX_N - 1] = {0}; // diagonais contrarias (linha - coluna + N - 1)

    // comecar a busca recursiva a partir da primeira coluna (coluna=0)
    backtrack(0, N, tabuleiro, linhas_ocupadas, diagonais1_ocupadas, diagonais2_ocupadas);

    // print final
    printf("Resultados para um tabuleiro %dx%d:\n", N, N);

    if (contagem_solucoes == 0) {

        printf("Nao ha solucao para <%d> rainhas.\n", N);

    } else {

        for (int i = 0; i < contagem_solucoes; i++) {
            printar_solucao(N, solucoes[i]);
        }
        printf("\nO numero total de chamadas recursivas realizadas: %d\n", chamadas_recursivas);
        printf("A quantidade total de solucoes distintas encontradas: %d\n", contagem_solucoes);
    }
}



void backtrack(int col, int n, int tabuleiro[MAX_N], int linhas_ocupadas[MAX_N], int diagonais1_ocupadas[2 * MAX_N - 1], int diagonais2_ocupadas[2 * MAX_N - 1]) {
    
    chamadas_recursivas++;

    // caso base, todas as rainhas colocadas
    if (col == n) {
        processar_solucao(n, tabuleiro);
        return;
    }

    // tentar colocar a rainha em cada linha da coluna atual
    for (int row = 0; row < n; row++) {

        // ver se a posicao atual (linha,coluna) esta livre
        if (!linhas_ocupadas[row] && !diagonais1_ocupadas[row + col] && !diagonais2_ocupadas[row - col + n - 1]) {
            
            // colocar rainha
            tabuleiro[col] = row;
            linhas_ocupadas[row] = 1;
            diagonais1_ocupadas[row + col] = 1;
            diagonais2_ocupadas[row - col + n - 1] = 1;

            // proxima coluna
            backtrack(col + 1, n, tabuleiro, linhas_ocupadas, diagonais1_ocupadas, diagonais2_ocupadas);

            // tira rainha e desfaz mudanças (backtrack)
            linhas_ocupadas[row] = 0;
            diagonais1_ocupadas[row + col] = 0;
            diagonais2_ocupadas[row - col + n - 1] = 0;
        }
    }
}


// processar a solucao encontrada para verificar simetrias
void processar_solucao(int n, const int tabuleiro[MAX_N]) {

    int simetrias[8][MAX_N];
    int tabuleiro_canonico[MAX_N];

    // gerar as 8 simetrias do tabuleiro encontrado
    gerar_simetrias(n, tabuleiro, simetrias);

    // encontrar a forma canonica (a menor em ordem "alfabetica")
    forma_canonica(n, simetrias, tabuleiro_canonico);

    // se nao ja tiver sido encontrada, adicionar
    if (!solucao_ja_contabilizada(n, tabuleiro_canonico)) {
        add_solucao(n, tabuleiro_canonico);
    }
}


void gerar_simetrias(int n, const int* original, int simetrias[8][MAX_N]) {

    int temp_tabuleiro[MAX_N];

    // 0: identidade
    memcpy(simetrias[0], original, n * sizeof(int));
    
    // 1: rotacao 90 graus
    for (int i = 0; i < n; i++) temp_tabuleiro[original[i]] = n - 1 - i;
    memcpy(simetrias[1], temp_tabuleiro, n * sizeof(int));
    
    // 2: rotacao 180 graus
    for (int i = 0; i < n; i++) temp_tabuleiro[n - 1 - i] = n - 1 - original[i];
    memcpy(simetrias[2], temp_tabuleiro, n * sizeof(int));
    
    // 3: rotacao 270 graus
    for (int i = 0; i < n; i++) temp_tabuleiro[n - 1 - original[i]] = i;
    memcpy(simetrias[3], temp_tabuleiro, n * sizeof(int));

    // 4: reflexao vertical
    for (int i = 0; i < n; i++) temp_tabuleiro[n - 1 - i] = original[i];
    memcpy(simetrias[4], temp_tabuleiro, n * sizeof(int));

    // reflexao das rotacoes anteriores
    // 5: reflexao da rotacao 90 graus
    for (int i = 0; i < n; i++) temp_tabuleiro[original[i]] = i;
    memcpy(simetrias[5], temp_tabuleiro, n * sizeof(int));

    // 6: reflexao da rotacao 180 graus (reflexao horizontal)
    for (int i = 0; i < n; i++) temp_tabuleiro[i] = n - 1 - original[i];
    memcpy(simetrias[6], temp_tabuleiro, n * sizeof(int));

    // 7: reflexao da rotacao 270 graus
    for(int i = 0; i < n; i++) temp_tabuleiro[n - 1 - original[i]] = n - 1 - i;
    memcpy(simetrias[7], temp_tabuleiro, n * sizeof(int));
}

//achar a forma canonica do tabuleiro, que eh a menor em ordem "alfabetica"
void forma_canonica(int n, int simetrias[8][MAX_N], int tabuleiro_canonico[MAX_N]) {

    memcpy(tabuleiro_canonico, simetrias[0], n * sizeof(int));

    for (int i = 1; i < 8; i++) {

        if (memcmp(simetrias[i], tabuleiro_canonico, n * sizeof(int)) < 0) {

            memcpy(tabuleiro_canonico, simetrias[i], n * sizeof(int));
        }
    }
}


//ver se a forma canonica ja foi contabilizada
int solucao_ja_contabilizada(int n, const int tabuleiro[MAX_N]) {
    for (int i = 0; i < contagem_solucoes; i++) {

        // TESTE TESTE
        if (memcmp(solucoes[i], tabuleiro, n * sizeof(int)) == 0) {
            return 1; // encontrada
        }
    }
    return 0; // nao encontrada
}

// adiciona nova forma canonica
void add_solucao(int n, const int tabuleiro[MAX_N]) {
    if (contagem_solucoes < MAXIMO_SOLUCOES) {
        memcpy(solucoes[contagem_solucoes], tabuleiro, n * sizeof(int));
        contagem_solucoes++;
    }
}

//printa um vetor solucao
void printar_solucao(int n, const int tabuleiro[MAX_N]) {
    printf("  [ ");
    for (int i = 0; i < n; i++) {
        // tabuleiro[i] é a linha da coluna i
        printf("%d ", tabuleiro[i]);
    }
    printf("]\n");
}