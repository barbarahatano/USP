#ifndef NRAINHAS_H
#define NRAINHAS_H

void n_rainhas(int N);

#endif